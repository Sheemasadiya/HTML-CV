
from django.contrib import admin
from .models import Usersnew  # Import your User model

# Register the User model with the admin interface
admin.site.register(Usersnew)